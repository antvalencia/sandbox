from drop_cols import drop_cols
from headers import headers
import pandas as pd
import math

file = '2018BOS.EVA.csv'
extra_drop_cols = ['hit value', 'RBI on play', 'event type']
df = pd.read_csv(file, names=headers)
df = df.drop(drop_cols, axis=1)

total_count = len(df.index)
train_count = math.floor(total_count/2)
test_count = total_count - train_count

train_df = df[:train_count].copy()
test_df = df[train_count:].copy()



# hit - test
hit_test_df = test_df.copy()
hit_test_df['hit flag'] = 'T'
hit_test_df.loc[hit_test_df['hit value'] == 0, 'hit flag'] = 'F'
hit_test_df = hit_test_df.drop(extra_drop_cols, axis=1)
hit_df_cols = list(hit_test_df)
hit_test_df.to_csv('test.hit.csv', index=False)

# hit - train
hit_train_df = train_df.copy()
hit_train_df['hit flag'] = 'T'
hit_train_df.loc[hit_train_df['hit value'] == 0, 'hit flag'] = 'F'
hit_train_df = hit_train_df.drop(extra_drop_cols, axis=1)
hit_train_df.to_csv('train.hit.csv', index=False)

# hit- all
hit_all_df = df.copy()
hit_all_df['hit flag'] = 'T'
hit_all_df.loc[hit_all_df['hit value'] == 0, 'hit flag'] = 'F'
hit_all_df = hit_all_df.drop(extra_drop_cols, axis=1)
hit_all_df.to_csv('all.hit.csv', index=False)



# rbi - test
rbi_test_df = test_df.copy()
rbi_test_df['rbi flag'] = 'T'
rbi_test_df.loc[rbi_test_df['RBI on play'] == 0, 'rbi flag'] = 'F'
rbi_test_df = rbi_test_df.drop(extra_drop_cols, axis=1)
rbi_test_df.to_csv('test.rbi.csv', index=False)

# rbi - train
rbi_train_df = train_df.copy()
rbi_train_df['rbi flag'] = 'T'
rbi_train_df.loc[rbi_train_df['RBI on play'] == 0, 'rbi flag'] = 'F'
rbi_train_df = rbi_train_df.drop(extra_drop_cols, axis=1)
rbi_train_df.to_csv('train.rbi.csv', index=False)

# rbi - all
rbi_all_df = df.copy()
rbi_all_df['rbi flag'] = 'T'
rbi_all_df.loc[rbi_all_df['RBI on play'] == 0, 'rbi flag'] = 'F'
rbi_all_df = rbi_all_df.drop(extra_drop_cols, axis=1)
rbi_all_df.to_csv('all.rbi.csv', index=False)



# so - test
so_test_df = test_df.copy()
so_test_df['strike out flag'] = 'T'
so_test_df.loc[so_test_df['event type'] != 3, 'strike out flag'] = 'F'
so_test_df = so_test_df.drop(extra_drop_cols, axis=1)
so_test_df.to_csv('test.so.csv', index=False)

# so - train
so_train_df = train_df.copy()
so_train_df['strike out flag'] = 'T'
so_train_df.loc[so_train_df['event type'] != 3, 'strike out flag'] = 'F'
so_train_df = so_train_df.drop(extra_drop_cols, axis=1)
so_train_df.to_csv('train.so.csv', index=False)

# so - all
so_all_df = df.copy()
so_all_df['strike out flag'] = 'T'
so_all_df.loc[so_all_df['event type'] != 3, 'strike out flag'] = 'F'
so_all_df = so_all_df.drop(extra_drop_cols, axis=1)
so_all_df.to_csv('all.so.csv', index=False)
