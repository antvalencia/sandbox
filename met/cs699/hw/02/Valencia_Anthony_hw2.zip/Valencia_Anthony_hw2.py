import pandas as pd

a2p1_df = pd.read_csv('a2-p1.csv')

print("P1-1:")
a5_mean = a2p1_df['A5'].mean()
print("mean:", a5_mean)
a5_median = a2p1_df['A5'].median()
print("median:", a5_median)
a5_std = a2p1_df['A5'].std()
print("standard dev:", a5_std)
print("\n")

print("P1-2:")
q1 = a2p1_df['A5'].quantile([.25])[0.25]
print("Q1:", q1)
q2 = a2p1_df['A5'].quantile([.5])[0.5]
print("Q2:", q2)
q3 = a2p1_df['A5'].quantile([.75])[0.75]
print("Q3:", q3)
print("\n")

print("P1-3:")
iqr = q3 - q1
lower_outlier_threshold = q1 - (1.5 * iqr)
upper_outlier_threshold = q3 + (1.5 * iqr)
print("lower outliers:", a2p1_df[a2p1_df['A5'] < lower_outlier_threshold]['A5'].tolist())
print("upper outliers:", a2p1_df[a2p1_df['A5'] > upper_outlier_threshold]['A5'].tolist())
print("\n")

a2p2_df = pd.DataFrame(
    [
        {'ID': 'P1', 'Income': 60000, 'Age': 23},
        {'ID': 'P2', 'Income': 70000, 'Age': 27},
        {'ID': 'P3', 'Income': 75000, 'Age': 49},
        {'ID': 'P4', 'Income': 60000, 'Age': 52},
        {'ID': 'P5', 'Income': 95000, 'Age': 25},
        {'ID': 'P6', 'Income': 90000, 'Age': 65},
        {'ID': 'P7', 'Income': 100000, 'Age': 63},
        {'ID': 'P8', 'Income': 120000, 'Age': 38},
        {'ID': 'P9', 'Income': 27000, 'Age': 47},
        {'ID': 'P10', 'Income': 63000, 'Age': 72}
    ]
)

print("P2-1:")
p1 = a2p2_df[a2p2_df['ID'] == 'P1']
p2 = a2p2_df[a2p2_df['ID'] == 'P2']
p3 = a2p2_df[a2p2_df['ID'] == 'P3']
p12_dist = (
                   ((p1.Age.item() - p2.Age.item()) ** 2) +
                   ((p1.Income.item() - p2.Income.item()) ** 2)
           ) ** 0.5
print("d(P2,P1):", p12_dist)
p23_dist = (
                   ((p2.Age.item() - p3.Age.item()) ** 2) +
                   ((p2.Income.item() - p3.Income.item()) ** 2)
           ) ** 0.5
print("d(P2,P3):", p23_dist)
print("\n")

print("P2-2:")
income_mean = a2p2_df['Income'].mean()
income_std = a2p2_df['Income'].std()
age_mean = a2p2_df['Age'].mean()
age_std = a2p2_df['Age'].std()
p1_income_stdz = (p1.Income.item() - income_mean) / income_std
p1_age_stdz = (p1.Age.item() - age_mean) / age_std
p2_income_stdz = (p2.Income.item() - income_mean) / income_std
p2_age_stdz = (p2.Age.item() - age_mean) / age_std
p3_income_stdz = (p3.Income.item() - income_mean) / income_std
p3_age_stdz = (p3.Age.item() - age_mean) / age_std

p12_dist_stdz = (
                        ((p1_age_stdz - p2_age_stdz) ** 2) +
                        ((p1_income_stdz - p2_income_stdz) ** 2)
                ) ** 0.5
print("standardized d(P2,P1):", p12_dist_stdz)
p23_dist_stdz = (
                        ((p2_age_stdz - p3_age_stdz) ** 2) +
                        ((p2_income_stdz - p3_income_stdz) ** 2)
                ) ** 0.5
print("standardized d(P2,P3):", p23_dist_stdz)
print("\n")

print("P2-3:")
print("""P2 is closer to P1 than to P3.  much easier to see how much closer after standardizing to account for skewness
associated with order differences between variables' measuerments""")
print("\n")

print("P3:")
p3_df = pd.DataFrame(
    [
        {
            'ID': 'P1',
            'job': 'unemployed',
            'marital': 'married',
            'education': 'primary',
            'default': 'no',
            'housing': 'no',
            'loan': 'no',
            'contact': 'cellular'
        },
        {
            'ID': 'P2',
            'job': 'services',
            'marital': 'married',
            'education': 'secondary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'yes',
            'contact': 'cellular'
        },
        {
            'ID': 'P3',
            'job': 'management',
            'marital': 'single',
            'education': 'tertiary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'no',
            'contact': 'cellular'
        },
        {
            'ID': 'P4',
            'job': 'management',
            'marital': 'married',
            'education': 'tertiary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'yes',
            'contact': 'unknown'
        },
        {
            'ID': 'P5',
            'job': 'blue‐collar',
            'marital': 'married',
            'education': 'secondary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'no',
            'contact': 'unknown'
        },
        {
            'ID': 'P6',
            'job': 'management',
            'marital': 'single',
            'education': 'tertiary',
            'default': 'no',
            'housing': 'no',
            'loan': 'no',
            'contact': 'cellular'
        },
        {
            'ID': 'P7',
            'job': 'self‐employed',
            'marital': 'married',
            'education': 'tertiary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'no',
            'contact': 'cellular'
        },
        {
            'ID': 'P8',
            'job': 'technician',
            'marital': 'married',
            'education': 'secondary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'no',
            'contact': 'cellular'
        },
        {
            'ID': 'P9',
            'job': 'entrepreneur',
            'marital': 'married',
            'education': 'tertiary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'no',
            'contact': 'unknown'
        },
        {
            'ID': 'P10',
            'job': 'services',
            'marital': 'married',
            'education': 'primary',
            'default': 'no',
            'housing': 'yes',
            'loan': 'yes',
            'contact': 'cellular'
        }
    ]
)
p3_df = p3_df.set_index('ID')
print(p3_df)
d87 = (p3_df.loc['P8'].squeeze() != p3_df.loc['P7'].squeeze()) * 1
print("d(P8, P7):", d87.sum().item()/len(d87.index))
d89 = (p3_df.loc['P8'].squeeze() != p3_df.loc['P9'].squeeze()) * 1
print("d(P8, P9):", d89.sum().item()/len(d89.index))
print("\n")

print("P4:")
p4_df = pd.DataFrame(
    [
        {
            'Document': 'Document1', 'team': 5, 'coach': 0, 'hockey': 3, 'baseball': 0, 'soccer': 2,
            'penalty': 0, 'score': 0, 'win': 2, 'loss': 0, 'season': 0
        },
        {
            'Document': 'Document2', 'team': 3, 'coach': 0, 'hockey': 2, 'baseball': 0, 'soccer': 1,
            'penalty': 1, 'score': 0, 'win': 1, 'loss': 0, 'season': 1
        },
        {
            'Document': 'Document3', 'team': 0, 'coach': 7, 'hockey': 0, 'baseball': 2, 'soccer': 1,
            'penalty': 0, 'score': 0, 'win': 3, 'loss': 0, 'season': 0
        },
        {
            'Document': 'Document4', 'team': 0, 'coach': 1, 'hockey': 0, 'baseball': 0, 'soccer': 1,
            'penalty': 2, 'score': 2, 'win': 0, 'loss': 3, 'season': 0
        },
    ]
)
p4_df = p4_df.set_index('Document')
p4_d2 = p4_df.loc['Document2']
p4_d3 = p4_df.loc['Document3']
cosd2d3 = (p4_d2 * p4_d3).sum() / ((p4_d2 * p4_d2).sum() ** 0.5 * (p4_d3 * p4_d3).sum() ** 0.5)
print("cos(d2, d3):", cosd2d3)

p4_d4 = p4_df.loc['Document4']
cosd2d4 = (p4_d2 * p4_d4).sum() / ((p4_d2 * p4_d2).sum() ** 0.5 * (p4_d4 * p4_d4).sum() ** 0.5)
print("cos(d2, d4):", cosd2d4)
print("since cos(d2, d4) is closer to 1, d2 is more similar to d4")
